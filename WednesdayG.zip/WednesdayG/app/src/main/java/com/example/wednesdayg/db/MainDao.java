package com.example.wednesdayg.db;


import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

import ru.bestpango.mindrush.database.Entities.QuestionEntity;

@Dao
public interface MainDao {
    @Query("SELECT * FROM Questions order by Difficulty, Question ASC")
    List<QuestionEntity> getAllQuestions();

    @Query("Select * from Questions where Difficulty= :difficulty")
    List<QuestionEntity> getAllQuestionsOfDiffX(Integer difficulty);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void addNewQuestions(QuestionEntity question);

    @Query("Select * from Questions where ID=:index")
    QuestionEntity getByIndex(Integer index);

    @Query("delete from Questions")
    void deleteAll();

}
