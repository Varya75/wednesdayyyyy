package com.example.wednesdayg;
import android.app.Application;

import com.example.wednesdayg.db.MainDatabase;

import ru.bestpango.mindrush.database.MainDatabase;
import ru.bestpango.mindrush.database.Repostitory.RepositoryImpl;
import ru.bestpango.mindrush.database.Repostitory.Usecases.AddNewQ;
import ru.bestpango.mindrush.database.Repostitory.Usecases.GetAllQ;
import ru.bestpango.mindrush.database.Repostitory.Usecases.GetByID;

public class AppStart extends Application {

    private GetAllQ getAllQ;
    private AddNewQ addNewQ;
    private GetByID getByID;


    public GetAllQ getGetAllQ() {
        return getAllQ;
    }



    public AddNewQ getAddNewQ() {
        return addNewQ;
    }

    public GetByID getGetByID() {
        return getByID;
    }

    private static AppStart instance;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        MainDatabase db = MainDatabase.getInstance(this);
        RepositoryImpl rep = new RepositoryImpl(db.MainDao());
        getAllQ = new GetAllQ(rep);
        addNewQ = new AddNewQ(rep);
        getByID = new GetByID(rep);
        Database_Init.Init_Database();
        rep.updateQuestionList();
    }

    public static AppStart getInstance() {
        return instance;
    }
}
