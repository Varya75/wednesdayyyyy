package com.example.wednesdaygame;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class QuestionFragment extends Fragment {

    private QuestionFragment QuestionId;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_question, container, false);
    }

    public void setQuestionId(String item) {
        TextView QuestionId = getView().findViewById(R.id.question);
        QuestionId.setText(item);
    }

    public void getCurrentQuestion(String item) {
        String question = "";
        switch (getId()) {
            case 0:
                question = "Город, в котором происходят события первого сезона сериала Wednesday это Джерико?";
                break;
            case 1:
                question = "Предка wednesday зовут Гина Адамс?";
                break;
            case 2:
                question = "Wednesday носит только черно-белые наряды?";
                break;
            case 3:
                question = "Сериал снимался в более 100 локациях?";
                break;
            case 4:
                question = "Дженна Ортега научилась играть на виолончели для роли?";
                break;
            case 5:
                question = "Вещь - компьютерная графика?";
                break;
            case 6:
                question = "Wednesday не моргает?";
                break;
            case 7:
                question = "Wednesday пишет книгу?";
                break;
            case 8:
                question = "Энид является вампиром?";
                break;
            case 9:
                question = "Гомес - отец Wednesday?";
                break;

        }
        return question;
    }
}